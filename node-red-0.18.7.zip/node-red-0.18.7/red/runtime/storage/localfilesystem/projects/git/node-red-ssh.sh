ssh -i "$NODE_RED_KEY_FILE" -F /dev/null $@
